# Kbook

In this project we will create a fully functional Kbook that will not only look but also behave like real Kbook App. Most of the tutorials on the internet either create the complete UI or add the functionality but in this series I have done both parts for you.

## Link to the tutorial
https://youtu.be/i8VvGyeOuJ4?si=PxP8767oSDCaztAt

### Features of the app:
1. Chat and Messages
2. Add Friend
3. Make Posts
4. Post stories

# App Demo
![Kbook poster]